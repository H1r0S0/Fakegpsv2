package com.h1r0s.fakegps

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val geocoder by lazy { Geocoder(this, Locale.getDefault()) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web)

        // Serve assets from a real https origin so map tiles load without CORS issues
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/map.html")
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.refresh && refresh()", null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("window.refresh && refresh()", null)
        if (!hasLocation() && permissions.isNotEmpty() &&
            !shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)
        ) {
            // Permission permanently denied → open app settings
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.handleBack ? handleBack() : false") { r ->
            if (r != "true") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    // ---------------- checks ----------------

    private fun hasLocation() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun devModeOn() =
        Settings.Global.getInt(contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1

    private fun isMockApp(): Boolean = try {
        val ops = getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION, Process.myUid(), packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    private fun js(fn: String, json: JSONObject) {
        val arg = JSONObject.quote(json.toString())
        main.post { web.evaluateJavascript("window.$fn && $fn($arg)", null) }
    }

    private fun splitAddress(a: Address): Pair<String, String> {
        val line = a.getAddressLine(0)
            ?: listOfNotNull(a.featureName, a.thoroughfare, a.locality, a.countryName).distinct().joinToString(", ")
        val parts = line.split(", ", limit = 2)
        return parts[0] to parts.getOrElse(1) { "" }
    }

    // ---------------- JS bridge ----------------

    inner class Bridge {

        @JavascriptInterface
        fun state(): String = JSONObject()
            .put("running", MockLocationService.isRunning)
            .put("lat", MockLocationService.curLat)
            .put("lon", MockLocationService.curLon)
            .put("label", MockLocationService.curLabel ?: "")
            .put("error", MockLocationService.lastError ?: "")
            .put("perm", hasLocation())
            .put("dev", devModeOn())
            .put("mock", isMockApp())
            .toString()

        @JavascriptInterface
        fun search(query: String, id: Int) {
            val out = JSONObject().put("id", id)
            if (!Geocoder.isPresent()) {
                js("onSearchResults", out.put("error", "Поиск адресов недоступен на этом телефоне"))
                return
            }
            val deliver = { list: List<Address> ->
                val arr = JSONArray()
                list.forEach { a ->
                    val (t, s) = splitAddress(a)
                    arr.put(JSONObject().put("title", t).put("sub", s).put("lat", a.latitude).put("lon", a.longitude))
                }
                js("onSearchResults", out.put("results", arr))
            }
            val fail = { _: String? ->
                js("onSearchResults", out.put("error", "Не удалось выполнить поиск. Проверьте интернет."))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                geocoder.getFromLocationName(query, 6, object : Geocoder.GeocodeListener {
                    override fun onGeocode(addresses: MutableList<Address>) = deliver(addresses)
                    override fun onError(errorMessage: String?) = fail(errorMessage)
                })
            } else {
                io.execute {
                    try {
                        @Suppress("DEPRECATION")
                        deliver(geocoder.getFromLocationName(query, 6) ?: emptyList())
                    } catch (e: Exception) { fail(e.message) }
                }
            }
        }

        @JavascriptInterface
        fun reverse(lat: Double, lon: Double, id: Int) {
            val out = JSONObject().put("id", id)
            if (!Geocoder.isPresent()) { js("onAddress", out.put("title", "Точка на карте")); return }
            val deliver = { list: List<Address> ->
                if (list.isEmpty()) out.put("title", "Точка на карте")
                else { val (t, s) = splitAddress(list[0]); out.put("title", t).put("sub", s) }
                js("onAddress", out)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                geocoder.getFromLocation(lat, lon, 1, object : Geocoder.GeocodeListener {
                    override fun onGeocode(addresses: MutableList<Address>) = deliver(addresses)
                    override fun onError(errorMessage: String?) = deliver(emptyList())
                })
            } else {
                io.execute {
                    try {
                        @Suppress("DEPRECATION")
                        deliver(geocoder.getFromLocation(lat, lon, 1) ?: emptyList())
                    } catch (e: Exception) { deliver(emptyList()) }
                }
            }
        }

        @JavascriptInterface
        fun start(lat: Double, lon: Double, label: String) {
            MockLocationService.lastError = null
            val i = Intent(this@MainActivity, MockLocationService::class.java)
                .putExtra(MockLocationService.EXTRA_LAT, lat)
                .putExtra(MockLocationService.EXTRA_LON, lon)
                .putExtra(MockLocationService.EXTRA_LABEL, label)
            main.post { startForegroundService(i) }
        }

        @JavascriptInterface
        fun stop() {
            main.post { stopService(Intent(this@MainActivity, MockLocationService::class.java)) }
        }

        @JavascriptInterface
        fun requestPerms() {
            val need = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
            main.post { requestPermissions(need.toTypedArray(), 1) }
        }

        @JavascriptInterface
        fun openAbout() {
            main.post {
                try { startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        }

        @JavascriptInterface
        fun openDev() {
            main.post {
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        }
    }
}
